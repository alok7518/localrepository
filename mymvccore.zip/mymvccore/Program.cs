using Microsoft.AspNetCore.Authentication.Cookies;
using Serilog;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

//----------------------------------------------------------------------------------------------

Log.Logger = new LoggerConfiguration()
    .WriteTo.Console()
    .WriteTo.File("Logs/log-.txt")
    .CreateLogger();


builder.Host.UseSerilog();
//_____________________________________________________________________________________________

//type of authentication i need to use is:cookie based authentication
//the path of the login file
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme).AddCookie(
      c => { c.LoginPath = "/Hello/Login";c.AccessDeniedPath = "/Hello/Denied";});




//builder instance is required to add the services
var app = builder.Build();






// Configure the HTTP request pipeline.
/*if (!app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
}
else
{
    app.UseExceptionHandler("/Hello/MyPage");

}*/

//--------------------------------------------------------------------------------------------------------------//
//display 404 error
/* app.UseStatusCodePages();*/

//display custom page (the page which we have created)----url not changed only page name will show in url
//app.UseStatusCodePagesWithRedirects("/Hello/NotFound");


//display custom page (the page which we have created)----url changed which you will type that url take
//app.UseStatusCodePagesWithReExecute("/Hello/NotFound");


//-------------------------------------------------------------------------------------------------------------//


app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();


app.UseAuthentication();
app.UseAuthorization();



app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
