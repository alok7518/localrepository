﻿using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Security.Claims;

namespace mymvccore.Controllers
{
    public class HelloController : Controller
    {
        //implement DI
        ILogger<HelloController> log;
        public HelloController(ILogger<HelloController>logger) {
        log= logger;
        
        }

       // [Authorize(Roles ="manager")]
        public IActionResult Display()
        {
            //logs information in console window

            log.LogInformation("Display function called "+DateTime.Now);
            return View();
        }




        public IActionResult Index()
        {
            //display in red color
            log.LogError("Error occured in index method " + DateTime.Now);
            throw new DivideByZeroException();
        }

        public IActionResult MyPage()
        {
            return View();
        }


        public IActionResult Denied()
        {

            return View();
        }

        public IActionResult Login()
        {

            return View();
        }

        [HttpPost]
        public IActionResult Login(Employee e )
        {
            var res= (from t in Emplist.Getlist
                     where t.username == e.username && t.pwd == e.pwd
                     select t).FirstOrDefault();

            if (res!=null)
            {
                var userClaims = new List<Claim>()
                {
                        new Claim(ClaimTypes.Name, res.username),
                        new Claim(ClaimTypes.Role,res.Role),
                         new Claim(ClaimTypes.Country, res.Country),
                        };
                var identity = new ClaimsIdentity(userClaims, CookieAuthenticationDefaults.AuthenticationScheme);
                var principal = new ClaimsPrincipal(identity);

                var login = HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);
                return RedirectToAction("Display");
            }
            else
            {
                ViewData["v"] = "Inavalid username or password";
            }



            return View();
        }

        public IActionResult Logout()
        {
            var login = HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Login");
        }


        public IActionResult NotFound()
        {

        return View(); 
        }


        
    }




    public class Employee
    {
        public string username { get; set; }
        public string pwd { get; set; }
        public string Role { get; set; }
        public int Age { get; set; }
        public string Country { get; set; }
    }
    public static class Emplist
    {
        public static List<Employee> Getlist = new List<Employee>()
    {
         new Employee(){ username="vijay" , pwd="123" , Age=33, Country="india", Role="hr" },
         new Employee(){ username="raj" , pwd="123" , Age=29, Country="india", Role="manager" },
         new Employee(){ username="jay" , pwd="123" , Age=30, Country="canada", Role="admin" },
         new Employee(){ username="sujay" , pwd="123" , Age=25, Country="us", Role="manager" },
         new Employee(){ username="anil" , pwd="123" , Age=24, Country="us", Role="teamlead" },

    };
    }
}
